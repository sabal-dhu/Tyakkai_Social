(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a4853b1e._.js",
  "static/chunks/src_96d69466._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_391de2a8.css"
],
    source: "dynamic"
});
