(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5003273c._.js",
  "static/chunks/node_modules_7289d975._.js"
],
    source: "dynamic"
});
