(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_91cdc9bf._.js",
  "static/chunks/node_modules_76bb6e56._.js"
],
    source: "dynamic"
});
